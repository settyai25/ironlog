# API And Payment Notes

## Why Keys Are Server-Side

The original prototype called an AI API directly from browser JavaScript. That exposes secrets to every visitor. This version moves AI calls into:

- `api/coach.js`
- `api/analyze-food.js`

The browser only calls your own `/api/...` endpoints.

## Razorpay Flow

1. User logs in with email.
2. App starts a 30-day free trial.
3. After trial, the app displays plan buttons.
4. User selects monthly or yearly.
5. `/api/create-payment` creates a Razorpay order.
6. Razorpay Checkout collects payment.
7. `/api/verify-payment` verifies the signature.
8. The browser stores a paid access marker.

For a bigger production launch, store payment status in Supabase with a service-role key and verify it on every login. The current implementation is deployment-friendly and easy to extend, but a determined technical user could edit local browser storage.

## Plan Prices

- Monthly: `₹199`
- Yearly: `₹2000`
- Trial: 30 days

## No-Limit AI Warning

The app UI does not set a user-facing question limit, but OpenAI charges by usage. In production, set a reasonable daily quota per user to avoid surprise costs.
